﻿//Lines 1-9 are for utilizing a variety of functions in C#
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

//creates namespace for our GUI
namespace CSC202_GUI
{
    //Full function list for this form
    public partial class FRMpkm2 : Form
    {
        //constructor for this Form
        public FRMpkm2()
        {
            //initializes forms components
            InitializeComponent();
        }
        //function for our picture box
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            //grabbing our image from the file to use in form
            Image PKM2 = Image.FromFile("Mewtwo.png");
            //assigning our picture box to the variable
            pictureBox1.Image = PKM2;
        }
        //Calls function when button is clicked
        private void BTNcheck_Click(object sender, EventArgs e)
        {
            //If created if answer chosen is correct
            if (RBmew2.Checked)
            {
                //Messagebox will show when answer is checked
                MessageBox.Show("That's Correct!");
                //This is an instance of the next form
                FRMpkm3 frm = new FRMpkm3();
                //form currently in is now hidden
                this.Hide();
                //next will now show when button is pressed
                frm.Show();
            }
            //else created for if user chooses wrong answer
            else
            {
                //Messagebox will show when answer is checked
                MessageBox.Show("Incorrect, Try Again!");
            }
        }
    }
}
