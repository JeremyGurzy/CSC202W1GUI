﻿namespace CSC202_GUI
{
    partial class FRMpkm2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.GBpkm = new System.Windows.Forms.GroupBox();
            this.RBmew2 = new System.Windows.Forms.RadioButton();
            this.RBmimic = new System.Windows.Forms.RadioButton();
            this.RBpik = new System.Windows.Forms.RadioButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.BTNcheck = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.GBpkm.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // GBpkm
            // 
            this.GBpkm.Controls.Add(this.RBmew2);
            this.GBpkm.Controls.Add(this.RBmimic);
            this.GBpkm.Controls.Add(this.RBpik);
            this.GBpkm.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GBpkm.Location = new System.Drawing.Point(1057, 166);
            this.GBpkm.Name = "GBpkm";
            this.GBpkm.Size = new System.Drawing.Size(256, 326);
            this.GBpkm.TabIndex = 9;
            this.GBpkm.TabStop = false;
            this.GBpkm.Text = "Your Choices";
            // 
            // RBmew2
            // 
            this.RBmew2.AutoSize = true;
            this.RBmew2.Location = new System.Drawing.Point(30, 162);
            this.RBmew2.Name = "RBmew2";
            this.RBmew2.Size = new System.Drawing.Size(123, 30);
            this.RBmew2.TabIndex = 3;
            this.RBmew2.TabStop = true;
            this.RBmew2.Text = "MewTwo";
            this.RBmew2.UseVisualStyleBackColor = true;
            // 
            // RBmimic
            // 
            this.RBmimic.AutoSize = true;
            this.RBmimic.Location = new System.Drawing.Point(30, 236);
            this.RBmimic.Name = "RBmimic";
            this.RBmimic.Size = new System.Drawing.Size(118, 30);
            this.RBmimic.TabIndex = 2;
            this.RBmimic.TabStop = true;
            this.RBmimic.Text = "Mimikyu";
            this.RBmimic.UseVisualStyleBackColor = true;
            // 
            // RBpik
            // 
            this.RBpik.AutoSize = true;
            this.RBpik.Location = new System.Drawing.Point(30, 94);
            this.RBpik.Name = "RBpik";
            this.RBpik.Size = new System.Drawing.Size(115, 30);
            this.RBpik.TabIndex = 0;
            this.RBpik.TabStop = true;
            this.RBpik.Text = "Pikachu";
            this.RBpik.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(125, 166);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(600, 587);
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // BTNcheck
            // 
            this.BTNcheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNcheck.Location = new System.Drawing.Point(1057, 645);
            this.BTNcheck.Name = "BTNcheck";
            this.BTNcheck.Size = new System.Drawing.Size(256, 117);
            this.BTNcheck.TabIndex = 12;
            this.BTNcheck.Text = "Check Answer";
            this.BTNcheck.UseVisualStyleBackColor = true;
            this.BTNcheck.Click += new System.EventHandler(this.BTNcheck_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(529, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(428, 37);
            this.label1.TabIndex = 13;
            this.label1.Text = "Who\'s That Pocket Monster?";
            // 
            // FRMpkm2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ClientSize = new System.Drawing.Size(1538, 1024);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BTNcheck);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.GBpkm);
            this.Name = "FRMpkm2";
            this.Text = "Guess That Pocket Monster";
            this.GBpkm.ResumeLayout(false);
            this.GBpkm.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox GBpkm;
        private System.Windows.Forms.RadioButton RBmimic;
        private System.Windows.Forms.RadioButton RBpik;
        private System.Windows.Forms.RadioButton RBmew2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button BTNcheck;
        private System.Windows.Forms.Label label1;
    }
}