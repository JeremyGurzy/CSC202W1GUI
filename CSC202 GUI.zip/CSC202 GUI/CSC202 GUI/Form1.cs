﻿/*
 Jeremy Gurzynski
 CSC202
 jgurzynski85952@uat.edu
 Week 1 GUI Assignment
 */

//Lines 1-9 are for utilizing a variety of functions in C#
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//This allows sounds and videos to play in the GUI
using System.Media;


//creates namespace for our GUI
namespace CSC202_GUI
{
    //Full function list for this form
    public partial class TBf1Int : Form
    {
        //referenced a youtube video for this, will include link 
        //Variable and constructor created for our sound player
        private SoundPlayer soundPlayer;

        //constructor for this Form
        public TBf1Int()
        {
            //initializes forms components
            InitializeComponent();
            //assigned our variable to the .wav file
            soundPlayer = new SoundPlayer("WTPM.wav");
        }

        //when button is clicked THIS function will be called
        //Function for our check button
        private void BTNf1Check_Click(object sender, EventArgs e)
        {
            //to convert a textbox to an integer, you PARSE it however for this GUI I wanted a certain value. Little extra research prevailed utilizing this method
            //if created for user unput of correct answer
            if (this.TBf1.Text == "1025")
            {
                //Message will show if answer is correct
                MessageBox.Show("That is correct!");
            }
            //else created for if user enters wrong answer
            else
            {
                //Message will show if answer is incorrect
                MessageBox.Show("Incorrect, try again!");
            }
        }
        //Function will be called when button is clicked
        private void BTNfrm2_Click(object sender, EventArgs e)
        {
            //This is an instance of the next form
            FRMpkm1 frm = new FRMpkm1(textBox1.Text);
            //form currently in is now hidden
            this.Hide();
            //form 2 will now show when button is pressed
            frm.Show();
        }
        //function for our picture box
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            //grabbing our image from the file to use in form
            Image PKM = Image.FromFile("Pikachu2.png");
            //assigning our picture box to the variable
            pictureBox1.Image = PKM;
        }

        //Function will be called if user clicks button
        private void BTNsound_Click(object sender, EventArgs e)
        {
            //if for when user clicks button
            if (BTNsound.Enabled)
            {
                //This will play the sound
                soundPlayer.Play();
            }
        }
    }
}
