﻿namespace CSC202_GUI
{
    partial class FRMpkm3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.GBpkm = new System.Windows.Forms.GroupBox();
            this.RBray = new System.Windows.Forms.RadioButton();
            this.RBgir = new System.Windows.Forms.RadioButton();
            this.BTNcheck = new System.Windows.Forms.Button();
            this.RBpik = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.GBpkm.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(529, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(428, 37);
            this.label1.TabIndex = 14;
            this.label1.Text = "Who\'s That Pocket Monster?";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(125, 166);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(600, 587);
            this.pictureBox1.TabIndex = 15;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // GBpkm
            // 
            this.GBpkm.Controls.Add(this.RBpik);
            this.GBpkm.Controls.Add(this.RBray);
            this.GBpkm.Controls.Add(this.RBgir);
            this.GBpkm.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GBpkm.Location = new System.Drawing.Point(1057, 166);
            this.GBpkm.Name = "GBpkm";
            this.GBpkm.Size = new System.Drawing.Size(256, 326);
            this.GBpkm.TabIndex = 16;
            this.GBpkm.TabStop = false;
            this.GBpkm.Text = "Your Choices";
            // 
            // RBray
            // 
            this.RBray.AutoSize = true;
            this.RBray.Location = new System.Drawing.Point(30, 236);
            this.RBray.Name = "RBray";
            this.RBray.Size = new System.Drawing.Size(135, 30);
            this.RBray.TabIndex = 2;
            this.RBray.TabStop = true;
            this.RBray.Text = "Rayquaza";
            this.RBray.UseVisualStyleBackColor = true;
            // 
            // RBgir
            // 
            this.RBgir.AutoSize = true;
            this.RBgir.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.RBgir.Location = new System.Drawing.Point(30, 158);
            this.RBgir.Name = "RBgir";
            this.RBgir.Size = new System.Drawing.Size(113, 30);
            this.RBgir.TabIndex = 1;
            this.RBgir.TabStop = true;
            this.RBgir.Text = "Giratina";
            this.RBgir.UseVisualStyleBackColor = false;
            // 
            // BTNcheck
            // 
            this.BTNcheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNcheck.Location = new System.Drawing.Point(1057, 645);
            this.BTNcheck.Name = "BTNcheck";
            this.BTNcheck.Size = new System.Drawing.Size(256, 117);
            this.BTNcheck.TabIndex = 17;
            this.BTNcheck.Text = "Check Answer";
            this.BTNcheck.UseVisualStyleBackColor = true;
            this.BTNcheck.Click += new System.EventHandler(this.BTNcheck_Click);
            // 
            // RBpik
            // 
            this.RBpik.AutoSize = true;
            this.RBpik.Location = new System.Drawing.Point(30, 80);
            this.RBpik.Name = "RBpik";
            this.RBpik.Size = new System.Drawing.Size(115, 30);
            this.RBpik.TabIndex = 3;
            this.RBpik.TabStop = true;
            this.RBpik.Text = "Pikachu";
            this.RBpik.UseVisualStyleBackColor = true;
            // 
            // FRMpkm3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ClientSize = new System.Drawing.Size(1538, 1024);
            this.Controls.Add(this.BTNcheck);
            this.Controls.Add(this.GBpkm);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Name = "FRMpkm3";
            this.Text = "Guess That Pocket Monster";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.GBpkm.ResumeLayout(false);
            this.GBpkm.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox GBpkm;
        private System.Windows.Forms.RadioButton RBray;
        private System.Windows.Forms.RadioButton RBgir;
        private System.Windows.Forms.Button BTNcheck;
        private System.Windows.Forms.RadioButton RBpik;
    }
}