﻿//Lines 1-9 are for utilizing a variety of functions in C#
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//creates namespace for our GUI
namespace CSC202_GUI
{
    //Full function list for this form
    public partial class FRMpkm1 : Form
    {
        //constructor for this Form
        public FRMpkm1(string from1)
        {
            //initializes forms components
            InitializeComponent();
            //This will transfer text from form 1 to the next form
            TBtxFromF1.Text = from1;
        }
        //Not entirely sure why this is here, cannot delete without breaking the entire form
        private void FRMclass_Load(object sender, EventArgs e)
        {

        }
        //function for our picture box
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            //grabbing our image from the file to use in form
            Image PKM1 = Image.FromFile("Geodude.png");
            //assigning our picture box to the variable
            pictureBox1.Image = PKM1;
        }
        //Calls function when button is clicked
        private void BTNcheck_Click(object sender, EventArgs e)
        {
            //If created if answer chosen is correct
            if (RBgeo.Checked)
            {
                //Messagebox will show when answer is checked
                MessageBox.Show("That's Correct!");
                //This is an instance of the next form
                FRMpkm2 frm = new FRMpkm2();
                //form currently in is now hidden
                this.Hide();
                //next will now show when button is pressed
                frm.Show();

            }
            //else created for if user chooses wrong answer
            else
            {
                //Messagebox will show when answer is checked
                MessageBox.Show("Incorrect, Try Again!");
            }

        }
    }
}
