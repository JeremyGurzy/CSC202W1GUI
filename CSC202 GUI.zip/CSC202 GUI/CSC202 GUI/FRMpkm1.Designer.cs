﻿namespace CSC202_GUI
{
    partial class FRMpkm1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.GBpkm = new System.Windows.Forms.GroupBox();
            this.RBclef = new System.Windows.Forms.RadioButton();
            this.RBgeo = new System.Windows.Forms.RadioButton();
            this.RBmew = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.BTNcheck = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.TBtxFromF1 = new System.Windows.Forms.TextBox();
            this.GBpkm.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // GBpkm
            // 
            this.GBpkm.Controls.Add(this.RBclef);
            this.GBpkm.Controls.Add(this.RBgeo);
            this.GBpkm.Controls.Add(this.RBmew);
            this.GBpkm.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GBpkm.Location = new System.Drawing.Point(1057, 166);
            this.GBpkm.Name = "GBpkm";
            this.GBpkm.Size = new System.Drawing.Size(256, 326);
            this.GBpkm.TabIndex = 4;
            this.GBpkm.TabStop = false;
            this.GBpkm.Text = "Your Choices";
            // 
            // RBclef
            // 
            this.RBclef.AutoSize = true;
            this.RBclef.Location = new System.Drawing.Point(30, 236);
            this.RBclef.Name = "RBclef";
            this.RBclef.Size = new System.Drawing.Size(111, 30);
            this.RBclef.TabIndex = 2;
            this.RBclef.TabStop = true;
            this.RBclef.Text = "Clefairy";
            this.RBclef.UseVisualStyleBackColor = true;
            // 
            // RBgeo
            // 
            this.RBgeo.AutoSize = true;
            this.RBgeo.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.RBgeo.Location = new System.Drawing.Point(30, 158);
            this.RBgeo.Name = "RBgeo";
            this.RBgeo.Size = new System.Drawing.Size(126, 30);
            this.RBgeo.TabIndex = 1;
            this.RBgeo.TabStop = true;
            this.RBgeo.Text = "Geodude";
            this.RBgeo.UseVisualStyleBackColor = false;
            // 
            // RBmew
            // 
            this.RBmew.AutoSize = true;
            this.RBmew.Location = new System.Drawing.Point(30, 85);
            this.RBmew.Name = "RBmew";
            this.RBmew.Size = new System.Drawing.Size(83, 30);
            this.RBmew.TabIndex = 0;
            this.RBmew.TabStop = true;
            this.RBmew.Text = "Mew";
            this.RBmew.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(35, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(132, 32);
            this.label2.TabIndex = 6;
            this.label2.Text = "Welcome";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(125, 166);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(618, 579);
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // BTNcheck
            // 
            this.BTNcheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTNcheck.Location = new System.Drawing.Point(1057, 645);
            this.BTNcheck.Name = "BTNcheck";
            this.BTNcheck.Size = new System.Drawing.Size(256, 117);
            this.BTNcheck.TabIndex = 8;
            this.BTNcheck.Text = "Check Answer";
            this.BTNcheck.UseVisualStyleBackColor = true;
            this.BTNcheck.Click += new System.EventHandler(this.BTNcheck_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(529, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(428, 37);
            this.label1.TabIndex = 14;
            this.label1.Text = "Who\'s That Pocket Monster?";
            // 
            // TBtxFromF1
            // 
            this.TBtxFromF1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.TBtxFromF1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBtxFromF1.Location = new System.Drawing.Point(173, 44);
            this.TBtxFromF1.Name = "TBtxFromF1";
            this.TBtxFromF1.ReadOnly = true;
            this.TBtxFromF1.Size = new System.Drawing.Size(135, 30);
            this.TBtxFromF1.TabIndex = 15;
            // 
            // FRMpkm1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ClientSize = new System.Drawing.Size(1538, 1024);
            this.Controls.Add(this.TBtxFromF1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BTNcheck);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.GBpkm);
            this.Name = "FRMpkm1";
            this.Text = "Guess That Pocket Monster";
            this.Load += new System.EventHandler(this.FRMclass_Load);
            this.GBpkm.ResumeLayout(false);
            this.GBpkm.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox GBpkm;
        private System.Windows.Forms.RadioButton RBmew;
        private System.Windows.Forms.RadioButton RBclef;
        private System.Windows.Forms.RadioButton RBgeo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button BTNcheck;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TBtxFromF1;
    }
}